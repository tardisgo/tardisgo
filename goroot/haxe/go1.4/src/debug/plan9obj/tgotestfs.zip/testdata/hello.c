#include <u.h>
#include <libc.h>

void
main(void)
{
	print("hello, world\n");
}
