// this file here to make the tests pass after performance_test.go removed

package parser
