package bugpara

// BUG(rsc): Sometimes bugs have multiple paragraphs.
//
// Like this one.
