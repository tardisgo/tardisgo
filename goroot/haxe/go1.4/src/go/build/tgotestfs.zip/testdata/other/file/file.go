// Test data - not compiled.

package file

func F() {}
