// Test data - not compiled.

package main

import (
	"./file"
)

func main() {
	file.F()
}
