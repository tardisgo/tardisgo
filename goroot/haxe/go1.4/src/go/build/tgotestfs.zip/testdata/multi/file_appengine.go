// Test data - not compiled.

package test_package

func init() {}
